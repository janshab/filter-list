export const API = "https://jsonplaceholder.typicode.com";
export const postsContainer = document.getElementById("posts");
export const perPage = 10;
export const filteredElement = document.getElementById("filter");
